// Animation du titre lettre par lettre
function animateTitle() {
    const title = document.getElementById('animated-title');
    if (!title) return;
    
    const text = title.textContent;
    title.innerHTML = '';
    
    text.split('').forEach((char, index) => {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char; // Espace insécable pour les espaces
        span.className = 'char';
        span.style.animationDelay = `${index * 0.05}s`;
        title.appendChild(span);
    });
}

// Animation des liens de navigation au survol
function setupNavAnimations() {
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    navLinks.forEach(link => {
        const originalText = link.textContent;
        
        link.addEventListener('mouseenter', function() {
            // Créer les spans pour chaque lettre
            const chars = originalText.split('').map((char, index) => {
                const span = document.createElement('span');
                span.textContent = char === ' ' ? '\u00A0' : char;
                span.className = 'nav-char';
                span.style.animationDelay = `${index * 0.03}s`;
                return span;
            });
            
            // Vider et remplir le lien
            this.innerHTML = '';
            chars.forEach(span => this.appendChild(span));
        });
        
        link.addEventListener('mouseleave', function() {
            // Restaurer le texte original
            this.textContent = originalText;
        });
    });
}

// Animation du titre de section au survol
function setupSectionTitleAnimation() {
    const sectionTitles = document.querySelectorAll('.section-title');
    
    sectionTitles.forEach(title => {
        const originalText = title.textContent;
        
        // Diviser le titre en lettres
        const chars = originalText.split('').map((char, index) => {
            const span = document.createElement('span');
            span.textContent = char === ' ' ? '\u00A0' : char;
            span.className = 'char';
            return span;
        });
        
        // Vider et remplir le titre
        title.innerHTML = '';
        chars.forEach(span => title.appendChild(span));
    });
}

// Animation de lueur pour le CTA au scroll
function setupScrollGlow() {
    const ctaButton = document.querySelector('.cta-button');
    let glowActivated = false;

    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Activer la lueur quand l'utilisateur scroll vers le bas
        if (scrollTop > 200 && !glowActivated) {
            glowActivated = true;
            ctaButton.classList.add('scroll-glow');
        }
        
        // Désactiver la lueur si l'utilisateur remonte en haut
        if (scrollTop < 100 && glowActivated) {
            glowActivated = false;
            ctaButton.classList.remove('scroll-glow');
        }
    });
}

// Maintenir la navigation transparente pendant le scroll
function setupNavigationTransparency() {
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Garder la navigation transparente en permanence
        navbar.style.background = 'transparent';
    });
}

// Animation du carré gris au scroll
function setupSquareAnimation() {
    const square = document.querySelector('.square-placeholder');
    
    if (!square) return;
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Délai pour que l'animation se déclenche quand la section est visible
                setTimeout(() => {
                    entry.target.classList.add('animate');
                }, 300);
            }
        });
    }, {
        threshold: 0.3, // Déclenche quand 30% de la section est visible
        rootMargin: '0px 0px -50px 0px'
    });
    
    observer.observe(square);
}

// Fonctions pour le système de slide
function nextSlide() {
    const currentSlide = document.querySelector('.realisation-slide.active');
    const allSlides = document.querySelectorAll('.realisation-slide');
    const currentIndex = Array.from(allSlides).indexOf(currentSlide);
    const nextIndex = (currentIndex + 1) % allSlides.length;
    const nextSlide = allSlides[nextIndex];
    
    // Retirer la classe active du slide actuel
    currentSlide.classList.remove('active');
    
    // Ajouter la classe active au nouveau slide
    nextSlide.classList.add('active');
    
    // Réinitialiser l'animation du carré pour le nouveau slide
    const newSquare = nextSlide.querySelector('.square-placeholder');
    if (newSquare) {
        newSquare.classList.remove('animate');
        setTimeout(() => {
            newSquare.classList.add('animate');
        }, 300);
    }
}

function prevSlide() {
    const currentSlide = document.querySelector('.realisation-slide.active');
    const allSlides = document.querySelectorAll('.realisation-slide');
    const currentIndex = Array.from(allSlides).indexOf(currentSlide);
    const prevIndex = (currentIndex - 1 + allSlides.length) % allSlides.length;
    const prevSlide = allSlides[prevIndex];
    
    // Retirer la classe active du slide actuel
    currentSlide.classList.remove('active');
    
    // Ajouter la classe active au nouveau slide
    prevSlide.classList.add('active');
    
    // Réinitialiser l'animation du carré pour le nouveau slide
    const newSquare = prevSlide.querySelector('.square-placeholder');
    if (newSquare) {
        newSquare.classList.remove('animate');
        setTimeout(() => {
            newSquare.classList.add('animate');
        }, 300);
    }
}

// Fonction pour ouvrir WhatsApp
function openWhatsApp() {
    // Numéro WhatsApp de l'utilisateur (format international français)
    const phoneNumber = "33786080164";
    const message = "Bonjour ! Je suis intéressé par vos services de landing pages.";
    
    // Format plus robuste pour WhatsApp
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
    
    try {
        window.open(whatsappUrl, '_blank');
    } catch (error) {
        // Fallback si l'ouverture échoue
        window.location.href = whatsappUrl;
    }
}

// Fonction pour gérer le formulaire d'email
function setupEmailForm() {
    const emailForm = document.getElementById('emailForm');
    const confirmationMsg = document.createElement('div');
    confirmationMsg.className = 'confirmation-message';
    confirmationMsg.style.marginTop = '2rem';
    confirmationMsg.style.fontSize = '1.2rem';
    confirmationMsg.style.color = '#1a1a1a';
    confirmationMsg.style.textAlign = 'center';
    confirmationMsg.style.fontWeight = '500';
    
    if (emailForm) {
        emailForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const phone = document.getElementById('phone').value;
            const submitBtn = document.querySelector('.submit-btn');
            const phoneRegex = /^(\+33|0)[1-9](\d{8})$/;
            if (phone && phoneRegex.test(phone.replace(/\s/g, ''))) {
                submitBtn.classList.add('slide-out');
                // Envoi AJAX à Zapier
                fetch('https://hooks.zapier.com/hooks/catch/24023906/u44t3lf/', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `phone=${encodeURIComponent(phone)}`
                })
                .then(response => {
                    setTimeout(() => {
                        submitBtn.classList.remove('slide-out');
                        emailForm.reset();
                        confirmationMsg.textContent = 'Merci ! Votre numéro a été enregistré. Nous vous contacterons bientôt sur WhatsApp !';
                        emailForm.parentNode.appendChild(confirmationMsg);
                        emailForm.style.display = 'none';
                    }, 800);
                })
                .catch(error => {
                    setTimeout(() => {
                        submitBtn.classList.remove('slide-out');
                        confirmationMsg.textContent = "Une erreur est survenue. Veuillez réessayer.";
                        emailForm.parentNode.appendChild(confirmationMsg);
                    }, 800);
                });
            } else {
                alert('Veuillez entrer un numéro de téléphone français valide (ex: 0612345678 ou +33612345678)');
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    animateTitle();
    setupNavAnimations();
    setupScrollGlow();
    setupNavigationTransparency();
    setupSectionTitleAnimation();
    setupSquareAnimation();
    setupEmailForm(); // Ajouter la fonction pour le formulaire d'email
    
    // Smooth scrolling pour les liens de navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Toggle menu mobile
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Fermer le menu mobile en cliquant sur un lien
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // FAQ toggle
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', function() {
            const faqItem = this.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Fermer tous les autres items
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Ouvrir/fermer l'item cliqué
            if (!isActive) {
                faqItem.classList.add('active');
            }
        });
    });
}); 